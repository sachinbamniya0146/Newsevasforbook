import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  Browsers,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion,
  delay
} from '@whiskeysockets/baileys';

import P from 'pino';
import readline from 'readline';
import qrcode from 'qrcode-terminal';
import fs from 'fs';
import { handleMessage } from './handlers/messageHandler.js';
import { handleAdminMessage, updateActiveSessions } from './handlers/adminHandler.js';
import { initScheduler } from './utils/scheduler.js';
import { logger } from './utils/logger.js';
import CONFIG from './config.js';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const sessions = new Map();
const retryMap = new Map();

// Validate and sanitize phone
function cleanPhoneNumber(phone) {
  return phone.trim().replace(/^+/, '').replace(/D/g, '');
}

// Create/delete session folder utility
function ensureSessionDir(sessionName) {
  const path = `./sessions/${sessionName}`;
  if (!fs.existsSync(path)) fs.mkdirSync(path, { recursive: true });
  return path;
}
function deleteSessionDir(sessionName) {
  const path = `./sessions/${sessionName}`;
  if (fs.existsSync(path)) fs.rmSync(path, { recursive: true, force: true });
}

function ask(q) {
  return new Promise(r => rl.question(q, r));
}

async function connect(sessionName, mode, phone = null, renew = false) {
  // Renew: delete all session files and folder before reconnecting
  if (renew) deleteSessionDir(sessionName);

  const sessionPath = ensureSessionDir(sessionName);

  try {
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    const browserConfigs = [
      Browsers.macOS('Safari'),
      Browsers.ubuntu('Chrome'),
      ['Chrome (Linux)', '', ''],
      Browsers.windows('Edge'),
      Browsers.appropriate('Desktop')
    ];
    const browserIndex = retryMap.get(sessionName) || 0;
    const selectedBrowser = browserConfigs[browserIndex % browserConfigs.length];

    const sock = makeWASocket({
      version,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
      },
      logger: P({ level: 'silent' }),
      browser: selectedBrowser,
      printQRInTerminal: false,
      syncFullHistory: false,
      markOnlineOnConnect: true,
      connectTimeoutMs: 65000,
      keepAliveIntervalMs: 30000,
      getMessage: async (key) => ({ conversation: '' }),
      retryRequestDelayMs: 300,
      maxMsgRetryCount: 3,
      shouldIgnoreJid: (jid) => jid.endsWith('@broadcast')
    });

    let pairingCodeAttempted = false;

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('CB:ib,,dirty', () => {});

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      // QR connect
      if (mode === 'qr' && qr && !state.creds.registered) {
        console.log(`
========= SCAN QR [${sessionName}] =========`);
        qrcode.generate(qr, { small: true });
        console.log(`WhatsApp > Linked Devices > Scan QR
`);
      }

      // Pairing code (normal & business both)
      if (mode === 'pair' && !pairingCodeAttempted && !state.creds.registered && phone) {
        if (['open', 'connecting'].includes(connection)) {
          pairingCodeAttempted = true;
          await delay(4000);
          try {
            let cleanPhone = cleanPhoneNumber(phone);
            if (cleanPhone.length < 10) throw new Error('Invalid phone');
            const code = await sock.requestPairingCode(cleanPhone);

            console.log(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
            console.log(`📱 SESSION: ${sessionName}`);
            console.log(`🔑 PAIRING CODE: ${code}`);
            console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
            console.log(`1. Open WhatsApp/Business`);
            console.log(`2. Settings(Menu) > Linked Devices`);
            console.log(`3. Link with phone number instead`);
            console.log(`4. Enter code: ${code} (expires in ~2 min)`);
            console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
          } catch (e) {
            logger.error(`[${sessionName}] Pairing error: ${e.message}`);
            if (renew === false) {
              console.log('
🔄 Retrying with session reset...
');
              return connect(sessionName, mode, phone, true);
            } else {
              console.log('🚨 Still failed after reset. Please update WhatsApp and try again.');
            }
          }
        }
      }

      if (connection === 'open') {
        logger.success(`✅ CONNECTED: ${sessionName}`);
        sessions.set(sessionName, sock);
        retryMap.delete(sessionName);
        updateActiveSessions(sessions);

        // Show WhatsApp user/number info
        const jid = sock.user?.id || 'Unknown';
        const phoneDisp = jid.split(':')[0];
        console.log(`
✅ SESSION ONLINE: ${sessionName} | Number: +${phoneDisp}
`);
        if (sessions.size === 1) {
          initScheduler(sock);
        }
      }

      if (connection === 'close') {
        const code = lastDisconnect?.error?.output?.statusCode;
        const shouldRetry = code !== DisconnectReason.loggedOut;
        logger.warn(`[${sessionName}] Disconnected: code=${code}`);
        if ([401, 403].includes(code)) {
          logger.error(`[${sessionName}] Invalid session files, deleting...`);
          deleteSessionDir(sessionName);
          sessions.delete(sessionName);
          retryMap.delete(sessionName);
          if (!renew) {
            return connect(sessionName, mode, phone, true);
          }
        } else if (shouldRetry) {
          const retries = retryMap.get(sessionName) || 0;
          if (retries < 5) {
            retryMap.set(sessionName, retries + 1);
            const delayTime = 8000 * (retries + 1);
            logger.info(`[${sessionName}] Retry ${retries + 1}/5 in ${delayTime/1000}s...`);
            await delay(delayTime);
            connect(sessionName, mode, phone, renew);
          } else {
            logger.error(`[${sessionName}] Max retries. Removing session files.`);
            deleteSessionDir(sessionName);
            sessions.delete(sessionName);
            retryMap.delete(sessionName);
          }
        } else {
          logger.error(`[${sessionName}] Logged out`);
          sessions.delete(sessionName);
          retryMap.delete(sessionName);
        }
      }
    });

    // Messages
    sock.ev.on('messages.upsert', async ({ messages }) => {
      for (const m of messages) {
        if (!m.message || m.key.fromMe) continue;
        const from = m.key.remoteJid;
        try {
          if (from === CONFIG.ADMIN.JID) await handleAdminMessage(sock, m);
          else await handleMessage(sock, m, sessionName);
        } catch (e) {
          logger.error(`[${sessionName}] Message error: ${e.message}`);
        }
      }
    });

  } catch (e) {
    logger.error(`[${sessionName}] Connection error: ${e.message}`);
  }
}

// Show all active sessions, remove, clear, etc.
async function autoStartAll() {
  try {
    if (!fs.existsSync('./sessions')) fs.mkdirSync('./sessions', { recursive: true });
    const dirs = fs.readdirSync('./sessions');
    let restored = 0;
    for (const dir of dirs) {
      const creds = `./sessions/${dir}/creds.json`;
      if (fs.existsSync(creds)) {
        logger.info(`🔄 Restoring: ${dir}`);
        connect(dir, 'qr');
        restored++;
        await delay(1800);
      }
    }
    return restored;
  } catch (e) {
    logger.error('Auto-start error: ' + e.message);
    return 0;
  }
}

async function menu() {
  console.log(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌟 Waseva Satguru Bot: Multi WhatsApp 🌟
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1 - Link WhatsApp (Pairing Code) 🔑
2 - Link WhatsApp (QR Code) 📷
3 - Show Active Sessions 📊
4 - Remove Session 🗑️
5 - Clear ALL Sessions ⚠️
6 - Exit 👋
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);

  const choice = await ask('Enter choice [1-6]: ');

  if (choice === '1') {
    const name = await ask('Session name (e.g. client1): ');
    if (!name || name.trim() === '') return menu();
    const phoneRaw = await ask('Phone (e.g. 919876543210): ');
    const phone = cleanPhoneNumber(phoneRaw);
    if (phone.length < 10) {
      console.log('❌ Invalid phone number, must be 10+ digits');
      return menu();
    }
    connect(name.trim(), 'pair', phone);
    console.log('
✅ Pairing code will appear in 4-8 seconds
');
    setTimeout(menu, 7000);
  }
  else if (choice === '2') {
    const name = await ask('Session name (e.g. client1): ');
    if (!name || name.trim() === '') return menu();
    connect(name.trim(), 'qr');
    console.log('
✅ QR code will appear in 4-8 seconds
');
    setTimeout(menu, 5000);
  }
  else if (choice === '3') {
    console.log(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📊 ACTIVE SESSIONS: ${sessions.size}`);
    let idx = 0;
    for (const [name, sock] of sessions) {
      const jid = sock.user?.id || 'Unknown';
      console.log(` ${++idx}. ${name} (${jid.split(':')[0]})`);
    }
    if (sessions.size === 0) console.log('❌ None!');
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
    setTimeout(menu, 1200);
  }
  else if (choice === '4') {
    if (sessions.size === 0) {
      console.log('❌ Nothing to remove
');
      return setTimeout(menu, 700);
    }
    let idx = 0;
    for (const name of sessions.keys()) {
      console.log(` ${++idx}. ${name}`);
    }
    const name = await ask('Session to remove: ');
    const sessionName = name.trim();
    if (sessions.has(sessionName)) {
      sessions.delete(sessionName);
      deleteSessionDir(sessionName);
      console.log(`✅ Removed: ${sessionName}`);
    } else {
      console.log('❌ Not found.');
    }
    setTimeout(menu, 1100);
  }
  else if (choice === '5') {
    const confirm = await ask('⚠️ Delete **ALL** saved sessions? yes/no: ');
    if (confirm.toLowerCase() === 'yes') {
      for (const name of fs.readdirSync('./sessions')) {
        deleteSessionDir(name);
      }
      sessions.clear();
      retryMap.clear();
      console.log('✅ All sessions cleared!');
      await delay(700);
    } else {
      console.log('Cancelled.');
    }
    setTimeout(menu, 1000);
  }
  else if (choice === '6') {
    console.log('
👋 Exiting Bot. Bye!
');
    process.exit(0);
  } else {
    console.log('❌ Invalid! Use 1-6 keys.');
    setTimeout(menu, 900);
  }
}

(async () => {
  logger.success('🚀 Waseva Satguru Bot — WhatsApp & Business 2025 Ready');
  const restored = await autoStartAll();
  if (restored > 0) {
    console.log(`✅ Restored ${restored} sessions
Bot running 24/7
`);
  } else {
    console.log('No existing sessions. Link your first WhatsApp account!');
  }
  menu();
})();

process.on('SIGINT', () => {
  console.log('
👋 Bot stopped. All sessions closed.
');
  process.exit(0);
});

process.on('uncaughtException', (e) => logger.error('Error: ' + e.message));
process.on('unhandledRejection', (e) => logger.error('Promise: ' + e.message));
