import { getOrderStats, getTodayOrders, getPendingOrders, searchOrderByMobile, getAllOrders } from '../utils/database.js';
import { logger } from '../utils/logger.js';

let activeSessions = new Map();

export function updateActiveSessions(sessions) {
  activeSessions = sessions;
}

export async function handleAdminMessage(sock, message) {
  try {
    const from = message.key.remoteJid;
    const msgText = (message.message.conversation || message.message.extendedTextMessage?.text || '').trim().toLowerCase();
    if (!msgText) return;

    if (msgText === 'आज की रिपोर्ट' || msgText === 'today report' || msgText === 'today') {
      const today = getTodayOrders();
      let msg = `📊 *आज की रिपोर्ट / Today Report*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 कुल ऑर्डर / Total Orders: *${today.length}*

`;
      if (today.length > 0) {
        today.forEach((o, i) => {
          msg += `${i + 1}. ${o.name}
   📚 ${o.book} (${o.language})
   📱 ${o.mobileNumber}
   📍 ${o.location}, ${o.pinCode}

`;
        });
      } else {
        msg += `❌ आज कोई ऑर्डर नहीं है।
_No orders today._`;
      }
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText === 'अधूरे ऑर्डर' || msgText === 'pending orders' || msgText === 'pending') {
      const pending = getPendingOrders();
      let msg = `📋 *अधूरे ऑर्डर / Pending Orders*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 कुल / Total: *${pending.length}*

`;
      if (pending.length > 0) {
        pending.forEach((o, i) => {
          msg += `${i + 1}. ${o.data?.name || 'Unknown'}
   Step: ${o.step}
   📱 ${o.whatsappNumber}

`;
        });
      } else {
        msg += `✅ कोई अधूरा ऑर्डर नहीं है।
_No pending orders._`;
      }
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText === 'कुल ऑर्डर' || msgText === 'total orders' || msgText === 'all orders') {
      const stats = getOrderStats();
      let msg = `📊 *कुल ऑर्डर सांख्यिकी / Total Order Statistics*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
      msg += `📦 कुल ऑर्डर / Total: *${stats.total}*
`;
      msg += `✅ पूर्ण / Completed: *${stats.completed}*
`;
      msg += `⏳ लंबित / Pending: *${stats.pending}*
`;
      msg += `📚 ज्ञान गंगा: *${stats.byBook['ज्ञान गंगा'] || 0}*
`;
      msg += `📚 जीने की राह: *${stats.byBook['जीने की राह'] || 0}*

`;
      msg += `🗣️ *भाषा के अनुसार / By Language:*
`;
      Object.entries(stats.byLanguage).forEach(([lang, count]) => {
        msg += `• ${lang}: ${count}
`;
      });
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText.startsWith('search ')) {
      const mobile = msgText.replace('search ', '').trim();
      const orders = searchOrderByMobile(mobile);
      let msg = `🔍 *Search Results for:* ${mobile}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
      if (orders.length > 0) {
        orders.forEach((o, i) => {
          msg += `
*Order ${i + 1}:*
`;
          msg += `🆔 ID: ${o.id}
`;
          msg += `👤 Name: ${o.name}
`;
          msg += `📚 Book: ${o.book} (${o.language})
`;
          msg += `📍 Address: ${o.location}, ${o.pinCode}
`;
          msg += `⏰ Time: ${new Date(o.timestamp).toLocaleString('hi-IN')}
`;
        });
      } else {
        msg += `
❌ No orders found.
_इस नंबर पर कोई ऑर्डर नहीं मिला।_`;
      }
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText === 'system status' || msgText === 'bot status' || msgText === 'status') {
      const stats = getOrderStats();
      const sessions = activeSessions.size;
      let msg = `🤖 *Bot System Status*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
      msg += `✅ Status: *Active & Running*
`;
      msg += `📱 Active Sessions: *${sessions}*
`;
      msg += `📦 Total Orders: *${stats.total}*
`;
      msg += `⏰ Last Updated: ${new Date().toLocaleString('hi-IN')}
`;
      msg += `💾 Memory: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)} MB
`;
      msg += `⏱️ Uptime: ${Math.floor(process.uptime() / 60)} minutes
`;
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText === 'help' || msgText === 'menu' || msgText === 'commands') {
      let msg = `🔧 *Admin Commands*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
      msg += `📊 today report - आज की रिपोर्ट
`;
      msg += `📋 pending orders - अधूरे ऑर्डर
`;
      msg += `📦 total orders - कुल ऑर्डर
`;
      msg += `🔍 search <mobile> - नंबर से खोजें
`;
      msg += `🤖 bot status - सिस्टम स्टेटस
`;
      msg += `📥 export orders - CSV डाउनलोड
`;
      msg += `❓ help - यह मेनू
`;
      await sock.sendMessage(from, { text: msg });
    }

    else if (msgText === 'export orders' || msgText === 'download orders') {
      const all = getAllOrders();
      let csv = `Order ID,Name,Father Name,Mobile,Alt Mobile,Book,Language,Location,Pincode,District,State,Timestamp,Status
`;
      all.forEach(o => {
        csv += `${o.id},${o.name},${o.fatherName},${o.mobileNumber},${o.altMobileNumber || ''},${o.book},${o.language},${o.location},${o.pinCode},${o.district},${o.state},${o.timestamp},${o.status}
`;
      });
      await sock.sendMessage(from, { document: Buffer.from(csv), mimetype: 'text/csv', fileName: `orders_${Date.now()}.csv` });
      await sock.sendMessage(from, { text: `✅ Orders exported successfully!
_Total: ${all.length} orders_` });
    }

    else {
      await sock.sendMessage(from, { text: `⚠️ Unknown command. Type 'help' for admin commands.
_अज्ञात कमांड। 'help' टाइप करें।_` });
    }

  } catch (e) {
    logger.error('Admin handler error:', e);
    await sock.sendMessage(from, { text: `❌ Error processing admin command.` });
  }
}
