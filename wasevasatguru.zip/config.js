export default {
  // 👑 MAIN ADMIN (Default - Sabhi orders yaha jayenge)
  ADMIN: {
    JID: '919174406375@s.whatsapp.net',
    PHONE: '919174406375',
    NAME: 'Main Admin',
    PRIVILEGES: 'FULL' // FULL access to all features
  },
  
  // 📱 PER-SESSION ADMIN MAPPING
  // Har WhatsApp session ke liye alag admin set kar sakte ho
  // Admin menu se dynamically add/remove hoga
  // Format: { 'session_name': { adminJID: 'phone@s.whatsapp.net', forwardOrders: true } }
  SESSION_ADMINS: {
    // Runtime me fill hoga via admin commands
    // Example:
    // 'satish1': { adminJID: '919876543210@s.whatsapp.net', forwardOrders: true, addedAt: '2025-11-22' }
  },
  
  // 🏢 ORDER GROUP
  ORDER_GROUP_NAME: 'Order_received_on_WhatsApp',
  USER_GROUP_LINK: 'https://chat.whatsapp.com/LcTW8DuZzV23uhVc7BBcAu',
  
  // 📚 BOOK PDFS (Complete List)
  BOOK_PDFS: {
    'ज्ञान गंगा': {
      'हिन्दी': 'https://www.jagatgururampalji.org/gyan_ganga_hindi.pdf',
      'English': 'https://www.jagatgururampalji.org/gyan_ganga_english.pdf',
      'ਪੰਜਾਬੀ': 'https://www.jagatgururampalji.org/jeene-ki-rah-punjabi.pdf',
      'ગુજરાતી': 'https://www.jagatgururampalji.org/jeene-ki-rah-gujarati.pdf',
      'मराठी': 'https://www.jagatgururampalji.org/jeene-ki-rah-marathi.pdf',
      'தமிழ்': 'https://www.jagatgururampalji.org/gyan_ganga_hindi.pdf',
      'తెలుగు': 'https://www.jagatgururampalji.org/jeene-ki-rah-telugu.pdf',
      'ಕನ್ನಡ': 'https://www.jagatgururampalji.org/jkr-kannad.pdf',
      'ଓଡ଼ିଆ': 'https://www.jagatgururampalji.org/jkr-odia.pdf',
      'മലയാളം': 'https://www.jagatgururampalji.org/gyan-ganga-malayalam.pdf',
      'অসমীয়া': 'https://www.jagatgururampalji.org/jeene-ki-rah-bengali.pdf',
      'नेपाली': 'https://www.jagatgururampalji.org/jeene-ki-rah-nepali.pdf',
      'বাংলা': 'https://www.jagatgururampalji.org/jeene-ki-rah-bengali.pdf',
      'اردو': 'https://www.jagatgururampalji.org/gyan_ganga_urdu.pdf',
      'سنڌي': 'https://www.jagatgururampalji.org/gyan_ganga_sindhi.pdf',
      'Español': 'https://www.jagatgururampalji.org/gyan_ganga_hindi.pdf',
      'Français': 'https://www.jagatgururampalji.org/gyan_ganga_french.pdf'
    },
    'जीने की राह': {
      'हिन्दी': 'https://www.jagatgururampalji.org/jeene-ki-rah.pdf',
      'English': 'https://www.jagatgururampalji.org/way-of-living.pdf',
      'ਪੰਜਾਬੀ': 'https://www.jagatgururampalji.org/jeene-ki-rah-punjabi.pdf',
      'ગુજરાતી': 'https://www.jagatgururampalji.org/jeene-ki-rah-gujarati.pdf',
      'मराठी': 'https://www.jagatgururampalji.org/jeene-ki-rah-marathi.pdf',
      'தமிழ்': 'https://www.jagatgururampalji.org/jeene-ki-rah.pdf',
      'తెలుగు': 'https://www.jagatgururampalji.org/jeene-ki-rah-telugu.pdf',
      'ಕನ್ನಡ': 'https://www.jagatgururampalji.org/jkr-kannad.pdf',
      'ଓଡ଼ିଆ': 'https://www.jagatgururampalji.org/jkr-odia.pdf',
      'മലയാളം': 'https://www.jagatgururampalji.org/jkr_malayalam.pdf',
      'অসমীয়া': 'https://www.jagatgururampalji.org/jeene-ki-rah-bengali.pdf',
      'नेपाली': 'https://www.jagatgururampalji.org/jeene-ki-rah-nepali.pdf',
      'বাংলা': 'https://www.jagatgururampalji.org/jeene-ki-rah-bengali.pdf',
      'اردو': 'https://www.jagatgururampalji.org/jeene-ki-rah-urdu-india.pdf',
      'سنڌي': 'https://www.jagatgururampalji.org/gyan_ganga_sindhi.pdf',
      'Español': 'https://www.jagatgururampalji.org/jeene-ki-rah.pdf',
      'Français': 'https://www.jagatgururampalji.org/way-of-living.pdf'
    }
  },

  // 💬 MESSAGES
  DELIVERY_MSG: `📦 *डिलीवरी:* 7-21 दिन (निःशुल्क)\n_7-21 days (Free)_`,
  SUPPORT_CONTACT: `📞 *सहायता / Support:*\n+91 8586003472\n+91 9555000808`,
  BOT_NAME: 'Waseva Satguru Bot',
  BOT_VERSION: '4.0.0-ULTRA',
  WELCOME_MSG: `🙏 *नमस्ते! Namaste!*\n🌳 वेद-गीता प्रमाणित मोक्षज्ञान\n_Vedic Knowledge for Salvation_`,
  ORDER_SUCCESS_MSG: `🎉 *ऑर्डर सफलतापूर्वक दर्ज!*\n_Order Successfully Placed!_`,
  GROUP_JOIN_MSG: `📢 *हमारे WhatsApp ग्रुप से जुड़ें:*\n_Join our WhatsApp Group:_`,

  // 🔌 CONNECTION STABILITY (FIX 440 ERROR - NO MORE DISCONNECTS!)
  CONNECTION: {
    MAX_RETRIES: 20,                        // 20 retries max
    INITIAL_RETRY_DELAY_MS: 2000,           // 2 seconds first retry
    MAX_RETRY_DELAY_MS: 120000,             // 2 min max delay
    EXPONENTIAL_BACKOFF: true,              // Smart exponential: 2s, 4s, 8s, 16s, 32s, 60s, 120s
    EXPONENTIAL_MULTIPLIER: 2,              // Double delay har retry pe
    KEEP_ALIVE_INTERVAL_MS: 20000,          // 20 sec keepalive
    AUTO_RECONNECT: true,
    CONNECTION_TIMEOUT_MS: 120000,          // 2 min connection timeout
    HEARTBEAT_INTERVAL_MS: 25000,           // 25 sec heartbeat
    WEBSOCKET_PING_INTERVAL_MS: 15000,      // 15 sec WebSocket ping
    NOTIFY_ADMIN_ON_DISCONNECT: true,       // Admin ko notify (one-time only)
    NOTIFY_ADMIN_ON_RECONNECT: true,        // Reconnect success notify
    DISCONNECT_NOTIFICATION_COOLDOWN: 600000, // 10 min cooldown - baar baar nahi
    STABLE_CONNECTION_THRESHOLD: 120000,    // 2 min stable = success
    ENABLE_PRESENCE_UPDATES: true,          // Presence updates for health check
    DISABLE_OFFLINE_MODE: true,             // Never go offline
    FORCE_ONLINE_STATUS: true,              // Always online
    CONNECTION_HEALTH_CHECK_INTERVAL: 60000, // 1 min health check
    AUTO_RESTART_ON_CRITICAL_ERROR: true,   // Critical error pe auto-restart
    GRACEFUL_SHUTDOWN_TIMEOUT_MS: 10000,    // 10 sec graceful shutdown
    PREVENT_LOGOUT_ON_440: true,            // 440 code pe logout mat karo
    MAINTAIN_SESSION_PERSISTENCE: true,     // Session persist karo
    USE_STORE_FOR_MESSAGES: true,           // Message store enable
    CACHE_MESSAGES: true,                   // Messages cache karo
    SYNC_FULL_HISTORY: false                // Full history sync disable (stability)
  },

  // 📲 REMOTE PAIRING SYSTEM (Admin 919174406375 se remotely pair karo)
  REMOTE_PAIRING: {
    ENABLED: true,
    ADMIN_CAN_PAIR: true,                   // Main admin se pairing
    PAIRING_CODE_FORWARD: true,             // Pairing code admin WhatsApp pe forward
    PAIRING_CODE_FORWARD_TO_DEVICE: true,   // Already paired device se forward
    PAIRING_CODE_EXPIRY_MINUTES: 5,         // 5 min expiry
    AUTO_ACCEPT_PAIRING: false,             // Manual confirmation required
    SESSION_NAME_PROMPT: true,              // "Session name kya rakhna hai?"
    PHONE_NUMBER_PROMPT: true,              // "Phone number kya link karna hai?"
    PAIRING_SUCCESS_NOTIFY: true,           // Success message admin ko
    PAIRING_FAILURE_NOTIFY: true,           // Failure message admin ko
    FORWARD_PAIRING_CODE_TO_ADMIN: true,    // Termux ka code admin WhatsApp pe
    PAIRING_COMMAND: '/pair',               // Admin command for remote pairing
    PAIRING_INSTRUCTIONS: true,             // Step-by-step guide bhejo
    ALLOW_MULTIPLE_PAIRING_SESSIONS: true,  // Multiple sessions ek saath pair
    MAX_PAIRING_ATTEMPTS: 3,                // Max 3 attempts per session
    PAIRING_RETRY_DELAY_MS: 5000,           // 5 sec retry delay
    VALIDATE_PHONE_NUMBER: true,            // Phone number validation
    COUNTRY_CODE_DEFAULT: '91'              // Default country code (India)
  },

  // 📊 ORDER FORWARDING SYSTEM (Multi-Admin Support)
  ORDER_FORWARDING: {
    FORWARD_TO_MAIN_ADMIN: true,            // Main admin 919174406375 ko always forward
    FORWARD_TO_SESSION_ADMIN: true,         // Session-specific admin ko bhi forward
    FORWARD_TO_GROUP: true,                 // Group me bhi forward
    DUPLICATE_TO_ALL_ADMINS: false,         // Duplicate nahi - only relevant admin
    INCLUDE_SESSION_INFO: true,             // Order message me session name include karo
    INCLUDE_ORDER_COUNT: true,              // Order count show karo
    INCLUDE_TIMESTAMP: true,                // Timestamp show karo
    FORMAT_ORDER_MESSAGE: true,             // Formatted order message
    ADD_ORDER_ID: true,                     // Unique order ID assign karo
    TRACK_ORDER_STATUS: true,               // Order status track karo
    ADMIN_REPLY_TRACKING: true,             // Admin ne reply kiya ya nahi
    SESSION_ADMIN_PRIORITY: 'SESSION_FIRST', // SESSION_FIRST ya MAIN_FIRST
    FALLBACK_TO_MAIN_ADMIN: true,           // Session admin fail ho to main admin pe bhejo
    ORDER_NOTIFICATION_FORMAT: 'DETAILED'   // DETAILED ya COMPACT
  },

  // 🛡️ BULK SENDING SYSTEM (24/7 with 100 Templates + Anti-Ban)
  BULK: {
    // 📂 Excel File Settings
    EXCEL_FOLDER_PATH: '/storage/emulated/0/Order_seva_system_contact_excel/',
    MOVE_COMPLETED_TO: '/storage/emulated/0/Order_seva_system_contact_excel/completed/',
    EXCEL_BACKUP_PATH: '/storage/emulated/0/Order_seva_system_contact_excel/backup/',
    AUTO_DETECT_EXCEL_FILES: true,          // Automatically detect new Excel files
    EXCEL_FILE_PATTERNS: ['*.xlsx', '*.xls'], // Supported formats
    COLUMN_NUMBER: 1,                       // Column 1 = Phone numbers
    COLUMN_NAME: 2,                         // Column 2 = Names
    SKIP_HEADER_ROW: true,                  // First row skip karo
    VALIDATE_PHONE_NUMBERS: true,           // Invalid numbers skip karo
    
    // 📈 Progressive Scaling (Day 1: 8 msgs, then +10% daily)
    DAY_1_LIMIT: 8,                         // First day only 8 messages
    DAILY_INCREMENT_PERCENT: 10,            // Har din 10% increase
    MAX_DAILY_LIMIT: 400,                   // Maximum 400 per day per WhatsApp
    ENABLE_PROGRESSIVE_SCALING: true,       // Progressive scaling enable
    TRACK_DAILY_LIMITS: true,               // Daily limit track karo
    RESET_DAILY_LIMIT_AT_HOUR: 0,           // Midnight pe reset
    
    // ⏱️ Human Simulation (Anti-Ban Timing)
    MIN_DELAY_SECONDS: 120,                 // 2 min minimum
    MAX_DELAY_SECONDS: 420,                 // 7 min maximum
    RANDOMIZATION_FACTOR: 0.45,             // ±45% variation
    RANDOM_BURST_CHANCE: 0.15,              // 15% chance for quick message (1 min)
    RANDOM_PAUSE_CHANCE: 0.10,              // 10% chance for long pause (10 min)
    SIMULATE_HUMAN_PATTERNS: true,          // Human-like behavior
    VARY_MESSAGE_SPEED: true,               // Message speed vary karo
    
    // ⌨️ Typing Simulation
    TYPING_DURATION_MIN_MS: 2000,           // 2 sec typing min
    TYPING_DURATION_MAX_MS: 5000,           // 5 sec typing max
    TYPING_BASED_ON_MESSAGE_LENGTH: true,   // Message length se typing time calculate
    TYPING_SPEED_WPM: 45,                   // 45 words per minute (natural)
    PRESENCE_ENABLED: true,                 // "online" status show karo
    TYPING_INDICATOR: true,                 // "typing..." indicator
    PAUSE_AFTER_SEND: true,                 // Send ke baad pause
    POST_SEND_PAUSE_MS: 1500,               // 1.5 sec pause after send
    READ_SIMULATION: true,                  // "read" receipts enable
    READ_DELAY_MS: 800,                     // 800ms read delay
    
    // 🔄 Multi-Session Rotation (Load Balancing)
    ROTATION_STRATEGY: 'intelligent',       // intelligent, round-robin, least-used
    SESSION_COOLDOWN_MINUTES: 20,           // 20 min cooldown after use
    MAX_MESSAGES_PER_SESSION_HOUR: 25,      // Max 25 msgs per hour per session
    AUTO_DISTRIBUTE_LOAD: true,             // Automatically distribute across sessions
    EQUAL_DISTRIBUTION: true,               // Equally distribute across WhatsApp
    PREFER_IDLE_SESSIONS: true,             // Idle session ko prefer karo
    TRACK_SESSION_HEALTH: true,             // Session health monitor karo
    PAUSE_UNHEALTHY_SESSIONS: true,         // Unhealthy session ko pause karo
    
    // 🔁 Recovery & Retry
    AUTO_RESUME: true,                      // Auto resume on failure
    RESUME_AFTER_MINUTES: 5,                // 5 min baad resume
    RETRY_FAILED: true,                     // Failed messages retry karo
    MAX_RETRIES: 3,                         // Max 3 retries per message
    RETRY_DELAY_MINUTES: 30,                // 30 min delay between retries
    SKIP_INVALID_NUMBERS: true,             // Invalid numbers skip karo
    MARK_FAILED_AS_COMPLETED: false,        // Failed messages ko completed mat mark karo
    
    // 🕐 Business Hours (9 AM - 8 PM IST)
    BUSINESS_HOURS_ONLY: true,              // Only business hours me bhejo
    START_HOUR_IST: 9,                      // 9 AM start
    END_HOUR_IST: 20,                       // 8 PM end
    TIMEZONE: 'Asia/Kolkata',               // IST timezone
    EXCLUDE_LUNCH_HOURS: true,              // Lunch time skip karo
    LUNCH_START_HOUR: 13,                   // 1 PM
    LUNCH_END_HOUR: 14,                     // 2 PM
    PAUSE_ON_WEEKENDS: false,               // Weekends pe bhi chale
    PAUSE_ON_HOLIDAYS: false,               // Holidays pe bhi chale
    
    // 📝 Content Quality
    MIN_MESSAGE_LENGTH: 20,                 // Minimum 20 characters
    MAX_MESSAGE_LENGTH: 350,                // Maximum 350 characters
    PERSONALIZATION_REQUIRED: true,         // {name} variable must ho
    VALIDATE_MESSAGE_CONTENT: true,         // Content validate karo
    REMOVE_EXTRA_SPACES: true,              // Extra spaces remove karo
    CAPITALIZE_NAMES: true,                 // Names capitalize karo
    TRIM_WHITESPACE: true,                  // Whitespace trim karo
    
    // 📋 Template System (100 Preset Templates)
    USE_FOOTER: false,                      // NO footer
    USE_TEMPLATE_ROTATION: true,            // Template rotation enabled
    TEMPLATES_COUNT: 100,                   // 100 templates
    TEMPLATE_PERSONALIZATION: true,         // {name} variable support
    TEMPLATE_SELECTION: 'RANDOM',           // RANDOM, SEQUENTIAL, WEIGHTED
    TEMPLATE_COOLDOWN_MESSAGES: 50,         // 50 messages ke baad repeat
    EMOJI_ROTATION: true,                   // Emoji vary karo
    GREETING_ROTATION: true,                // "नमस्ते", "Hello", etc. vary karo
    CONTENT_VARIATION: true,                // Content slightly vary karo
    
    // 📊 Reporting & Logs
    DAILY_REPORT_TIME: '18:30',             // 6:30 PM report
    SEND_ADMIN_NOTIFICATIONS: true,         // Admin ko notifications bhejo
    LOG_EVERY_N_MESSAGES: 5,                // Har 5 messages pe log
    TRACK_SUCCESS_RATE: true,               // Success rate track karo
    TRACK_FAILURE_REASONS: true,            // Failure reasons track karo
    GENERATE_DAILY_SUMMARY: true,           // Daily summary generate karo
    EXPORT_LOGS: true,                      // Logs export karo
    LOG_FILE_PATH: './logs/bulk_sending.log',
    
    // 🛡️ Advanced Anti-Ban Features
    ENABLE_MESSAGE_SPACING: true,           // Messages me spacing
    ENABLE_SESSION_WARMUP: true,            // New sessions ko warm-up karo
    WARMUP_MESSAGES_COUNT: 5,               // 5 warmup messages first
    WARMUP_DELAY_HOURS: 2,                  // 2 hours warmup period
    ENABLE_CONTENT_VARIATION: true,         // Content variation
    ENABLE_EMOJI_ROTATION: true,            // Emoji rotation
    VERIFY_NUMBER_BEFORE_SEND: true,        // Number verify before send
    CHECK_NUMBER_ON_WHATSAPP: true,         // Check if number exists on WhatsApp
    AVOID_DUPLICATE_MESSAGES: true,         // Same message dobara na bhejo
    DUPLICATE_CHECK_WINDOW_HOURS: 24,       // 24 hours me duplicate check
    
    // 🔐 Safety & Compliance
    WARMING_PERIOD_DAYS: 10,                // 10 din warming period
    WARMING_MESSAGE_LIMIT: 30,              // Warming me max 30 msgs/day
    SPAM_DETECTION_ENABLED: true,           // Spam detection
    AUTO_PAUSE_ON_FAILURE_RATE: 0.30,       // 30% fail = auto pause
    AUTO_PAUSE_ON_BLOCK: true,              // Block hone pe pause
    RESPECT_USER_OPTOUT: true,              // User opt-out respect karo
    BLACKLIST_ENABLED: true,                // Blacklist support
    WHITELIST_ENABLED: false,               // Whitelist disable (send to all)
    
    // 🚀 Performance
    ENABLE_CACHING: true,                   // Caching enable
    CACHE_EXPIRY_MINUTES: 60,               // 1 hour cache
    BATCH_SIZE: 10,                         // Process 10 at a time
    CONCURRENT_SESSIONS: 5,                 // Max 5 sessions parallel
    MEMORY_EFFICIENT_MODE: true,            // Memory efficient
    LOW_RAM_MODE: false,                    // Low RAM mode (Termux)
    
    // 🎯 Campaign Management
    ENABLE_CAMPAIGNS: true,                 // Campaigns support
    AUTO_START_CAMPAIGNS: false,            // Manual start required
    PAUSE_BETWEEN_CAMPAIGNS_HOURS: 12,      // 12 hours gap between campaigns
    CAMPAIGN_DAILY_LIMIT: 1,                // 1 campaign per day max
    TRACK_CAMPAIGN_METRICS: true,           // Campaign metrics track
    
    // 📞 Contact Management
    SAVE_CONTACTS: false,                   // Contacts save mat karo (privacy)
    AUTO_ADD_TO_PHONEBOOK: false,           // Phonebook me add mat karo
    USE_BUSINESS_API: false,                // Business API nahi (regular WhatsApp)
    
    // 24/7 Operation
    RUN_24_7: true,                         // 24/7 run karo
    AUTO_RESTART_ON_ERROR: true,            // Error pe auto restart
    RESTART_COOLDOWN_MINUTES: 5,            // 5 min cooldown before restart
    MAX_AUTO_RESTARTS_PER_DAY: 10,          // Max 10 restarts per day
    ENABLE_NIGHT_MODE: false                // Night mode disable (always active)
  },

  // 🔔 NOTIFICATION SETTINGS
  NOTIFICATIONS: {
    SESSION_CONNECTED: true,                // ✅ Session connected
    SESSION_DISCONNECTED: true,             // ⚠️ Session disconnected (one-time)
    SESSION_RECONNECTED: true,              // ✅ Session reconnected
    SESSION_FAILED: true,                   // ❌ Session failed (max retries)
    NEW_ORDER_RECEIVED: true,               // 🎉 New order
    DAILY_REPORT_ENABLED: true,             // 📊 Daily 6:30 PM report
    BULK_CAMPAIGN_STARTED: true,            // 🚀 Campaign started
    BULK_CAMPAIGN_COMPLETE: true,           // ✅ Campaign completed
    BULK_CAMPAIGN_PAUSED: true,             // ⏸️ Campaign paused
    LOW_BALANCE_ALERT: false,               // Not applicable
    ERROR_ALERTS: true,                     // ❌ Critical errors
    ADMIN_COMMAND_CONFIRMATION: true,       // ✅ Command executed
    PAIRING_CODE_NOTIFICATION: true,        // 📲 Pairing code
    SESSION_ADMIN_ADDED: true,              // ➕ Session admin added
    SESSION_ADMIN_REMOVED: true,            // ➖ Session admin removed
    NOTIFICATION_SOUND: false,              // No sound (WhatsApp handles this)
    NOTIFICATION_VIBRATION: false           // No vibration
  },

  // 🗂️ DATA STORAGE PATHS
  DATA_PATHS: {
    ORDERS_DB: './data/orders.json',
    SESSION_ADMINS_DB: './data/session_admins.json',
    BULK_STATE_DB: './data/bulk/bulk_state.json',
    BULK_PROGRESS_DB: './data/bulk/progress.json',
    TEMPLATES_DB: './data/templates.json',
    CAMPAIGN_DB: './data/bulk/campaigns.json',
    BLACKLIST_DB: './data/blacklist.json',
    LOGS_DIR: './logs',
    SESSIONS_DIR: './sessions',
    BACKUP_DIR: './backup',
    EXCEL_ARCHIVE_DIR: './data/bulk/excel_archive'
  },

  // 🔐 SECURITY & PERMISSIONS
  SECURITY: {
    ADMIN_ONLY_COMMANDS: true,              // Only main admin
    SESSION_ADMIN_COMMANDS: true,           // Session admin limited access
    ENABLE_COMMAND_LOGGING: true,           // Log all commands
    RESTRICT_PAIRING_TO_ADMIN: true,        // Only admin can pair
    RESTRICT_BULK_TO_ADMIN: true,           // Only admin can start bulk
    REQUIRE_CONFIRMATION_FOR_CRITICAL: true, // Critical actions need confirmation
    ALLOW_SESSION_ADMIN_VIEW_ONLY: true,    // Session admin can only view their orders
    ENCRYPTION_ENABLED: false,              // No encryption (not needed)
    RATE_LIMIT_COMMANDS: true,              // Rate limit to prevent spam
    MAX_COMMANDS_PER_MINUTE: 10             // Max 10 commands/min
  },

  // 🎨 UI & DISPLAY
  UI: {
    USE_EMOJIS: true,                       // Emojis in messages
    USE_COLORS: true,                       // Terminal colors
    SHOW_PROGRESS_BAR: true,                // Progress bar in bulk sending
    SHOW_SESSION_STATUS: true,              // Session status display
    COMPACT_MODE: false,                    // Full detailed mode
    SHOW_TIMESTAMPS: true,                  // Show timestamps
    USE_ASCII_ART: true,                    // Figlet ASCII art for title
    LANGUAGE: 'HINDI_ENGLISH'               // Bilingual support
  },

  // ⚙️ SYSTEM SETTINGS
  SYSTEM: {
    AUTO_UPDATE_CHECK: false,               // No auto-update
    TELEMETRY_ENABLED: false,               // No telemetry
    DEBUG_MODE: false,                      // Debug mode off
    VERBOSE_LOGGING: false,                 // Not verbose
    LOG_LEVEL: 'INFO',                      // INFO level
    MAX_LOG_FILE_SIZE_MB: 50,               // 50 MB max log size
    LOG_ROTATION_ENABLED: true,             // Log rotation
    BACKUP_ENABLED: true,                   // Auto backup
    BACKUP_INTERVAL_HOURS: 24,              // Daily backup
    MAX_BACKUPS: 7,                         // Keep 7 days
    CLEANUP_OLD_LOGS_DAYS: 30,              // Delete logs after 30 days
    MEMORY_LIMIT_MB: 512,                   // 512 MB memory limit (Termux)
    CPU_LIMIT_PERCENT: 80,                  // 80% CPU max
    PERFORMANCE_MONITORING: true            // Monitor performance
  },

  // 🌐 API & INTEGRATIONS (Future)
  INTEGRATIONS: {
    ENABLE_WEBHOOKS: false,
    ENABLE_API_SERVER: false,
    ENABLE_WEB_DASHBOARD: false,
    ENABLE_TELEGRAM_BRIDGE: false,
    ENABLE_EMAIL_NOTIFICATIONS: false
  }
};
