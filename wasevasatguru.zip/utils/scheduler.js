import cron from 'node-cron';
import { sendDailyNotifications } from './rotationManager.js';
import { getOrders } from './database.js';
import { sendToOrderGroup } from './groupManager.js';
import CONFIG from '../config.js';

let activeSock = null;
let activeSession = null;

export function initScheduler(sock, sessionName) {
  activeSock = sock;
  activeSession = sessionName;
  
  cron.schedule('0 9 * * *', async () => {
    console.log('✅ 9 AM Daily Notification Task Running...');
    if (activeSock) {
      await sendDailyNotifications(activeSock);
    }
  }, {
    scheduled: true,
    timezone: "Asia/Kolkata"
  });

  cron.schedule('30 18 * * *', async () => {
    console.log('📊 6:30 PM Daily Report Task Running...');
    if (activeSock && activeSession) {
      await sendDailyReport(activeSock, activeSession);
    }
  }, {
    scheduled: true,
    timezone: "Asia/Kolkata"
  });

  console.log(`✅ Scheduler initialized for ${sessionName}`);
}

async function sendDailyReport(sock, sessionName) {
  try {
    const allOrders = await getOrders();
    const now = new Date();
    const yesterday = new Date(now.getTime() - 24*60*60*1000);
    
    const last24HOrders = allOrders.filter(o => {
      const orderTime = new Date(o.timestamp);
      return orderTime >= yesterday && orderTime <= now;
    });

    if (last24HOrders.length === 0) {
      const reportMsg = "📊 *दैनिक रिपोर्ट* (Daily Report)\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nपिछले 24 घंटे में कोई नया ऑर्डर नहीं आया।\n(No new orders in last 24 hours)";
      await sendToOrderGroup(sock, sessionName, reportMsg);
      try { await sock.sendMessage(CONFIG.ADMIN.JID, { text: reportMsg }); } catch{}
      return;
    }

    let reportMsg = "📊 *दैनिक रिपोर्ट* (Daily Report)\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    reportMsg += `आज गुरु जी की असीम कृपा से ${last24HOrders.length} ऑर्डर आये हैं जी।\n\n`;
    
    last24HOrders.forEach((order, idx) => {
      reportMsg += `${idx+1}. ${order.name} (${order.mobile})\n   ${order.address}, ${order.pincode}\n   पुस्तक: ${order.bookName} (${order.language})\n\n`;
    });
    
    reportMsg += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🙏 धन्यवाद!";

    await sendToOrderGroup(sock, sessionName, reportMsg);
    try { await sock.sendMessage(CONFIG.ADMIN.JID, { text: reportMsg }); } catch{}
    
  } catch (err) {
    console.error('Daily report error:', err);
  }
}
