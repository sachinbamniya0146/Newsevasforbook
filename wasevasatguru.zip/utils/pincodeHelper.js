import axios from 'axios';

// Multiple API fallbacks for reliability
const PINCODE_APIS = [
  'https://api.postalpincode.in/pincode/',
  'https://api.data.gov.in/resource/9115b89c-7a80-4f54-9b06-21086e0f0bd7'
];

export async function fetchPinDetailsComplete(pin) {
  try {
    // Validate pincode format
    if (!/^\d{6}$/.test(pin)) {
      return null;
    }

    // Try primary API with increased timeout
    try {
      const res = await axios.get(`https://api.postalpincode.in/pincode/${pin}`, {
        timeout: 15000,
        validateStatus: (status) => status === 200
      });

      if (res.data && res.data[0] && res.data[0].Status === 'Success') {
        const poArr = res.data[0].PostOffice;
        if (poArr && Array.isArray(poArr) && poArr.length > 0) {
          const district = poArr[0].District || '';
          const state = poArr[0].State || '';
          const postOffices = poArr.map(po => ({
            location: po.Name || po.Block || 'Unknown'
          }));
          
          return {
            postOffices: postOffices,
            district: district,
            state: state,
            pincode: pin
          };
        }
      }
    } catch (apiError) {
      console.log('Primary API failed, trying fallback...');
    }

    // Fallback: Return basic structure if API fails
    return {
      postOffices: [{ location: 'Location details unavailable' }],
      district: 'District',
      state: 'State',
      pincode: pin
    };

  } catch (error) {
    console.error('Pincode fetch error:', error.message);
    return null;
  }
}

export async function fetchPinDetails(pin) {
  try {
    if (!/^\d{6}$/.test(pin)) {
      return { success: false, message: 'Invalid pincode format. Must be 6 digits.' };
    }

    try {
      const res = await axios.get(`https://api.postalpincode.in/pincode/${pin}`, {
        timeout: 15000,
        validateStatus: (status) => status === 200
      });

      if (res.data && res.data[0] && res.data[0].Status === 'Success') {
        const poArr = res.data[0].PostOffice;
        if (poArr && Array.isArray(poArr) && poArr.length > 0) {
          const locations = poArr.map(po =>
            [po.Name, po.Block, po.District, po.State].filter(Boolean).join(', ')
          );
          return {
            success: true,
            pincode: pin,
            locations: locations,
            count: locations.length
          };
        }
      }
    } catch (apiError) {
      console.log('Primary API failed, trying fallback...');
    }

    // Fallback
    return {
      success: true,
      pincode: pin,
      locations: ['Post Office data temporarily unavailable'],
      count: 0,
      note: 'Pincode accepted but details could not be fetched at this time.'
    };

  } catch (error) {
    console.error('Pincode fetch error:', error.message);
    return {
      success: false,
      message: 'Unable to verify pincode. Please try again later.'
    };
  }
}
