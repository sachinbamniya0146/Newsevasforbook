import CONFIG from '../config.js';

// Cache for group JIDs per session
const groupCache = new Map();

/**
 * Automatically find group by name and cache it
 * @param {Object} sock - WhatsApp socket
 * @param {string} sessionName - Session identifier
 * @returns {Promise<string|null>} Group JID or null
 */
export async function findOrderGroup(sock, sessionName) {
  try {
    // Check cache first
    if (groupCache.has(sessionName)) {
      return groupCache.get(sessionName);
    }

    console.log(`🔍 Searching for "${CONFIG.ORDER_GROUP_NAME}" group...`);

    // Fetch all groups
    const groups = await sock.groupFetchAllParticipating();
    
    // Find matching group
    for (const [jid, group] of Object.entries(groups)) {
      if (group.subject === CONFIG.ORDER_GROUP_NAME) {
        console.log(`✅ Found group: ${group.subject} (${jid})`);
        
        // Cache it
        groupCache.set(sessionName, jid);
        
        return jid;
      }
    }

    console.warn(`⚠️  Group "${CONFIG.ORDER_GROUP_NAME}" not found!`);
    console.warn('Make sure:');
    console.warn('1. Bot is added to the group');
    console.warn('2. Group name matches exactly: ' + CONFIG.ORDER_GROUP_NAME);
    
    return null;

  } catch (error) {
    console.error('Group search error:', error.message);
    return null;
  }
}

/**
 * Send message to order group (auto-detected)
 * @param {Object} sock - WhatsApp socket
 * @param {string} sessionName - Session identifier
 * @param {string} message - Message to send
 * @returns {Promise<boolean>} Success status
 */
export async function sendToOrderGroup(sock, sessionName, message) {
  try {
    const groupJID = await findOrderGroup(sock, sessionName);
    
    if (!groupJID) {
      console.error('Cannot send to group: Group not found');
      return false;
    }

    await sock.sendMessage(groupJID, { text: message });
    console.log('✅ Message sent to order group');
    return true;

  } catch (error) {
    console.error('Send to group error:', error.message);
    return false;
  }
}

/**
 * Clear cache for a session
 * @param {string} sessionName - Session identifier
 */
export function clearGroupCache(sessionName) {
  groupCache.delete(sessionName);
}

/**
 * Get all cached groups
 */
export function getAllCachedGroups() {
  return Array.from(groupCache.entries());
}
