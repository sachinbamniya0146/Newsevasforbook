import fs from 'fs';

const DB_FILE = './data/orders.json';

function ensureDB() {
  if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2));
}

export async function saveOrder(order) {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  order.id = Date.now();
  order.status = 'completed';
  orders.push(order);
  fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
  return order;
}

export async function getOrders() {
  ensureDB();
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

export async function getAllOrders() {
  ensureDB();
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

export function getTodayOrders() {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  const today = new Date().toISOString().split('T')[0];
  return orders.filter(o => o.timestamp && o.timestamp.startsWith(today));
}

export function getPendingOrders() {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  return orders.filter(o => o.status === 'pending');
}

export function searchOrderByMobile(mobile) {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  const clean = mobile.replace(/[^0-9]/g, '');
  return orders.filter(o => o.mobile && o.mobile.includes(clean));
}

export function getOrderStats() {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  
  const stats = {
    total: orders.length,
    completed: orders.filter(o => o.status === 'completed').length,
    pending: orders.filter(o => o.status === 'pending').length,
    byBook: {},
    byLanguage: {}
  };

  orders.forEach(o => {
    if (o.bookName) {
      stats.byBook[o.bookName] = (stats.byBook[o.bookName] || 0) + 1;
    }
    if (o.language) {
      stats.byLanguage[o.language] = (stats.byLanguage[o.language] || 0) + 1;
    }
  });

  return stats;
}

export async function getOrdersSince(hours) {
  const orders = await getOrders();
  const cutoff = Date.now() - (hours * 60 * 60 * 1000);
  return orders.filter(o => new Date(o.timestamp).getTime() > cutoff);
}

export async function clearOrders() {
  fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2));
}

export async function getStats() {
  const orders = await getOrdersSince(24);
  return {
    total: orders.length,
    gyanganga: orders.filter(o => o.bookName === 'ज्ञान गंगा').length,
    jeenekiraah: orders.filter(o => o.bookName === 'जीने की राह').length
  };
}

export function checkDuplicateOrder(mobile) {
  ensureDB();
  const orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  const exists = orders.some(o => o.mobile === mobile);
  return { isDuplicate: exists };
}
